# Copyright (c) 2025, Agibot Co., Ltd.
# OmniHand 2025 SDK is licensed under Mulan PSL v2

"""
OmniHand Pro 2025 (O12) Solver Module Type Stubs
"""

from typing import List

class OmniHandPro2025Solver:
    """OmniHand Pro 2025 (O12) kinematics solver"""
    
    def __init__(self, hand_type: bool) -> None:
        """
        Constructor
        
        Args:
            hand_type: True=left hand, False=right hand
        """
        ...
    
    def check_joint_pos(self, active_joint_pos: List[float]) -> bool:
        """
        Check if joint position is within limits
        
        Args:
            active_joint_pos: Active joint position vector (will be modified)
            
        Returns:
            Whether within limits
        """
        ...
    
    def check_actuator_input(self, actuator_input: List[int]) -> bool:
        """
        Check actuator input
        
        Args:
            actuator_input: Actuator input vector
            
        Returns:
            Whether valid
        """
        ...
    
    def set_hand_gesture(self, gesture_num: int) -> List[int]:
        """
            Set predefined hand gesture
        
        Args:
            gesture_num: Hand gesture index
            
        Returns:
            Actuator command vector
        """
        ...
    
    def convert_joint_to_actuator(self, active_joint_pos: List[float]) -> List[int]:
        """
        Convert active joint position to actuator input
        
        Args:
            active_joint_pos: Active joint position vector
            
        Returns:
            Actuator command vector (range: 0-2000)
            
        Note:
            O12 motor input range is 0-2000, different from O10 which is 0-4096
        """
        ...
    
    def convert_actuator_to_joint(self, actuator_input: List[int]) -> List[float]:
        """
        Convert actuator input to active joint position
        
        Args:
            actuator_input: Actuator command vector (range: 0-2000)
            
        Returns:
            Active joint position vector
            
        Note:
            O12 motor input range is 0-2000, different from O10 which is 0-4096
        """
        ...
    
    def active_joint_to_motor_length(self, active_joint_pos: List[float]) -> List[float]:
        """
        Convert active joint position to motor length
        
        Args:
            active_joint_pos: Active joint position vector
            
        Returns:
            Motor length vector
        """
        ...
    
    def motor_length_to_active_joint(self, motor_length: List[float]) -> List[float]:
        """
        Convert motor length to active joint position
        
        Args:
            motor_length: Motor length vector
            
        Returns:
            Active joint position vector
        """
        ...
    
    def motor_length_to_motor_input(self, motor_length: List[float]) -> List[int]:
        """
        Convert motor length to motor input
        
        Args:
            motor_length: Motor length vector
            
        Returns:
            Motor input vector
        """
        ...
    
    def motor_input_to_motor_length(self, motor_input: List[int]) -> List[float]:
        """
        Convert motor input to motor length
        
        Args:
            motor_input: Motor input vector
            
        Returns:
            Motor length vector
        """
        ...
    
    def get_all_joint_pos(self, active_joint_pos: List[float]) -> List[float]:
        """
        Get all joint positions (active + passive)
        
        Args:
            active_joint_pos: Current active joint position
            
        Returns:
            All joint position vector
        """
        ...
