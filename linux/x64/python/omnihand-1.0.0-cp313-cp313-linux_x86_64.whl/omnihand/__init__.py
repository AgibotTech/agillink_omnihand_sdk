# Copyright (c) 2025, Agibot Co., Ltd.
# OmniHand 2025 SDK is licensed under Mulan PSL v2

"""
OmniHand 2025 SDK Python Interface

This package supports OmniHand 2025 (O10, 10 DOF), OmniHand Pro 2025 (O12, 12 DOF), and OmniHand Dex UMI.

Usage:
    from omnihand import OmniHand2025, OmniHandPro2025, OmniHandDexUMI, EHandType, EFinger
    
    # For OmniHand 2025 (O10, 10 DOF):
    hand = OmniHand2025.create_hand_by_zlgcan(
        hand_type=EHandType.RIGHT,
        hand_device_id=1,
        canfd_device_id=0,
        canfd_channel_id=0
    )
    
    # For OmniHand Pro 2025 (O12, 12 DOF):
    hand = OmniHandPro2025.create_hand_by_zlgcan(
        hand_type=EHandType.LEFT,
        hand_device_id=1,
        canfd_device_id=0,
        canfd_channel_id=0
    )
    
    # For OmniHand Dex UMI:
    hand = OmniHandDexUMI.create_hand_by_zlgcan(
        hand_type=EHandType.LEFT,
        hand_device_id=1,
        canfd_device_id=0,
        canfd_channel_id=0
    )
"""

from .omnihand_core import (
    # Product-specific classes
    OmniHand2025,
    OmniHandPro2025,
    OmniHandDexUMI,
    # Common types
    EHandType,
    ProductType,
    EControlMode,
    EFinger,
    CommuParams,
    DeviceInfo,
    Version,
    VendorInfo,
    JointMotorErrorReport,
    MixCtrl,
    # O10-specific types
    TactileSensorData,
    # O12-specific types
    TactileSensor3DData,
    # Solvers
    OmniHand2025Solver,
    OmniHandPro2025Solver,
)

__all__ = [
    # Product-specific classes
    "OmniHand2025",
    "OmniHandPro2025",
    "OmniHandDexUMI",
    # Common types
    "EHandType",
    "ProductType",
    "EControlMode",
    "EFinger",
    "CommuParams",
    "DeviceInfo",
    "Version",
    "VendorInfo",
    "JointMotorErrorReport",
    "MixCtrl",
    # O10-specific types
    "TactileSensorData",
    # O12-specific types
    "TactileSensor3DData",
    # Solvers
    "OmniHand2025Solver",
    "OmniHandPro2025Solver",
]
