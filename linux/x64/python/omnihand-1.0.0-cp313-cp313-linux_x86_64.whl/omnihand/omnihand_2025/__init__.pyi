# Copyright (c) 2025, Agibot Co., Ltd.
# OmniHand 2025 SDK is licensed under Mulan PSL v2

"""
OmniHand 2025 (O10) Solver Module Type Stubs
提供10自由度灵巧手的运动学求解器接口
"""

from typing import List

class OmniHand2025Solver:
    """OmniHand 2025 (O10) kinematics solver - 10自由度灵巧手运动学求解器"""
    
    def __init__(self, hand_type: bool) -> None:
        """
        构造函数
        
        Args:
            hand_type: True=左手, False=右手
        """
        ...
    
    def set_hand_gesture(self, gesture_num: int) -> List[int]:
        """
        设置预定义手势
        
        Args:
            gesture_num: 手势索引
            
        Returns:
            执行器命令向量
        """
        ...
    
    def active_joint_pos_to_actuator_input(self, active_joint_pos: List[float]) -> List[int]:
        """
        Convert active joint position to actuator input
        
        Args:
            active_joint_pos: Active joint position vector
            
        Returns:
            Actuator command vector (range: 0-4096)
            
        Note:
            O10 motor input range is 0-4096, different from O12 which is 0-2000
        """
        ...
    
    def actuator_input_to_active_joint_pos(self, actuator_input: List[int]) -> List[float]:
        """
        Convert actuator input to active joint position
        
        Args:
            actuator_input: Actuator command vector (range: 0-4096)
            
        Returns:
            Active joint position vector
            
        Note:
            O10 motor input range is 0-4096, different from O12 which is 0-2000
        """
        ...
    
    def get_all_joint_pos(self, active_joint_pos: List[float]) -> List[float]:
        """
        获取所有关节位置 (主动+被动)
        
        Args:
            active_joint_pos: 当前主动关节位置
            
        Returns:
            所有关节位置向量
        """
        ...
    
    def show_log(self, flag: bool) -> None:
        """
        显示日志
        
        Args:
            flag: 是否显示日志
        """
        ...
