# Copyright (c) 2025, Agibot Co., Ltd.
# AGILINK OmniHand SDK is licensed under Mulan PSL v2

"""
AGILINK OmniHand SDK Python Interface

This package supports OmniHand 2025 (O10, 10 DOF), OmniHand Pro 2025 (O12, 12 DOF), 
OmniHand 3 Lite (O4, 4 DOF), and OmniHand Dex UMI.

Usage:
    from omnihand import OmniHand2025, OmniHandPro2025, OmniHand3Lite, OmniHandDexUMI, HandType, Finger
    
    # For OmniHand 2025 (O10, 10 DOF):
    hand = OmniHand2025.create_hand_by_zlgcan(
        hand_type=HandType.RIGHT,
        hand_device_id=OmniHand2025.kDefaultHandDeviceId,
        canfd_device_id=0,
        canfd_channel_id=0
    )
    
    # For OmniHand Pro 2025 (O12, 12 DOF):
    hand = OmniHandPro2025.create_hand_by_zlgcan(
        hand_type=HandType.LEFT,
        hand_device_id=OmniHandPro2025.kDefaultHandDeviceId,
        canfd_device_id=0,
        canfd_channel_id=0
    )
    
    # For OmniHand 3 Lite (O4, 4 DOF):
    hand = OmniHand3Lite.create_hand_by_zlgcan(
        hand_type=HandType.LEFT,
        hand_device_id=OmniHand3Lite.kDefaultHandDeviceId,
        canfd_device_id=0,
        canfd_channel_id=0
    )
    
    # For OmniHand Dex UMI:
    hand = OmniHandDexUMI.create_hand_by_zlgcan(
        hand_type=HandType.LEFT,
        hand_device_id=OmniHandDexUMI.kDefaultHandDeviceId,
        canfd_device_id=0,
        canfd_channel_id=0
    )
"""

from .omnihand_core import (
    # Product-specific classes
    OmniHand2025,
    OmniHandPro2025,
    OmniHand3Lite,
    OmniHand3UltraM,
    OmniHandDexUMI,
    # Common types
    HandType,
    ProductType,
    ControlMode,
    Finger,
    OmniHand2025Gesture,
    CommuParams,
    DeviceInfo,
    Version,
    VendorInfo,
    JointMotorErrorReport,
    MixCtrl,
    # O10-specific types
    TactileSensorData,
    # O12-specific types
    TactileSensor3DData,
    # Solvers
    OmniHand2025Solver,
    OmniHandPro2025Solver,
)


_H3UM_ERROR_BIT_NAMES = (
    'encoder_comm_timeout',
    'calibration_error',
    'over_voltage',
    'under_voltage',
    'over_temperature',
    'torque_saturation',
    'param_crc_error',
    'homing_error',
    'position_following_error',
    'velocity_following_error',
    'over_current',
    'inner_encoder_crc_error',
    'outer_encoder_crc_error',
    'encoder_multi_turn_error',
    'angle_identify_fail',
    'bit15_reserved',
)


def h3um_error_report_to_string(value: int) -> str:
    value &= 0xFFFF
    if value == 0:
        return '0'
    return ','.join(
        name for i, name in enumerate(_H3UM_ERROR_BIT_NAMES) if value & (1 << i)
    )

__all__ = [
    # Product-specific classes
    "OmniHand2025",
    "OmniHandPro2025",
    "OmniHand3Lite",
    "OmniHand3UltraM",
    "OmniHandDexUMI",
    # Common types
    "HandType",
    "ProductType",
    "ControlMode",
    "Finger",
    "OmniHand2025Gesture",
    "CommuParams",
    "DeviceInfo",
    "Version",
    "VendorInfo",
    "JointMotorErrorReport",
    "MixCtrl",
    # O10-specific types
    "TactileSensorData",
    # O12-specific types
    "TactileSensor3DData",
    # Solvers
    "OmniHand2025Solver",
    "OmniHandPro2025Solver",
    # H3U_M error report utility
    "h3um_error_report_to_string",
]
