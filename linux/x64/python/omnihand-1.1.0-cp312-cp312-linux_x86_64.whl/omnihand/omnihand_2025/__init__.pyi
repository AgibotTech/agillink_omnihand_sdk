# Copyright (c) 2025, Agibot Co., Ltd.
# AGILINK OmniHand SDK is licensed under Mulan PSL v2

"""OmniHand 2025 (O10) kinematics solver type stubs."""

from typing import List

from .. import OmniHand2025Gesture

class OmniHand2025Solver:
    """OmniHand 2025 (O10) kinematics solver"""

    def __init__(self, hand_type: bool) -> None:
        """hand_type: True=left hand, False=right hand."""
        ...

    def set_hand_gesture(
        self, gesture: OmniHand2025Gesture
    ) -> List[int]:
        """Set predefined hand gesture; returns actuator command vector."""
        ...

    def active_joint_pos_to_actuator_input(
        self, active_joint_pos: List[float]
    ) -> List[int]: ...

    def actuator_input_to_active_joint_pos(
        self, actuator_input: List[int]
    ) -> List[float]: ...

    def get_all_joint_pos(self, active_joint_pos: List[float]) -> List[float]: ...

    def show_log(self, flag: bool) -> None: ...
