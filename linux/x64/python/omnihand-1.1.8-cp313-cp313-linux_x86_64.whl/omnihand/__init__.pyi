# Copyright (c) 2025, Agibot Co., Ltd.
# AGILINK OmniHand SDK is licensed under Mulan PSL v2

"""
OmniHand 2025 SDK Python Type Stubs
Supports both OmniHand 2025 (O10, 10 DOF) and OmniHand 2025 Pro (O12, 12 DOF)
"""

from typing import List, Callable, Optional, Union
from enum import IntEnum

class HandType(IntEnum):
    LEFT = 0
    RIGHT = 1
    UNKNOWN = 255

class ProductType(IntEnum):
    OMNIHAND_2025 = 0
    OMNIHAND_PRO_2025 = 1
    OMNIHAND_DEX_UMI = 2
    OMNIHAND_3_LITE = 3
    OMNIHAND_3_ULTRA_M = 4
    UNKNOWN = 255

class ControlMode(IntEnum):
    POSITION = 0
    SERVO = 1
    VELOCITY = 2
    TORQUE = 3
    VOLTAGE = 4
    PROFILE_POSITION = 7
    UNKNOWN = 10

class MixControlMode(IntEnum):
    POSITION_TORQUE = 0x3
    VELOCITY_TORQUE = 0x4
    POSITION_VELOCITY_TORQUE = 0x5

class Finger(IntEnum):
    THUMB = 1
    INDEX = 2
    MIDDLE = 3
    RING = 4
    LITTLE = 5
    PALM = 6
    DORSUM = 7
    UNKNOWN = 255

class OmniHand2025Gesture(IntEnum):
    OMNIHAND_2025_GESTURE_ALL_ZERO = 0
    OMNIHAND_2025_GESTURE_PAPER = 1
    OMNIHAND_2025_GESTURE_FIST1 = 2
    OMNIHAND_2025_GESTURE_FIST2 = 3
    OMNIHAND_2025_GESTURE_OK = 4
    OMNIHAND_2025_GESTURE_ONE_HANDED_FINGER_HEART = 5
    OMNIHAND_2025_GESTURE_LIKE = 6
    OMNIHAND_2025_GESTURE_ILY = 7
    OMNIHAND_2025_GESTURE_NUM1 = 8
    OMNIHAND_2025_GESTURE_NUM2 = 9
    OMNIHAND_2025_GESTURE_NUM3 = 10
    OMNIHAND_2025_GESTURE_NUM4 = 11
    OMNIHAND_2025_GESTURE_NUM6 = 12
    OMNIHAND_2025_GESTURE_NUM8 = 13
    OMNIHAND_2025_GESTURE_HAND_HEART1 = 14
    OMNIHAND_2025_GESTURE_HAND_HEART2 = 15
    OMNIHAND_2025_GESTURE_HAND_HEART3 = 16
    OMNIHAND_2025_GESTURE_CLASPING = 17

class CommuParams:
    bitrate: int
    sample_point: int
    dbitrate: int
    dsample_point: int
    def __str__(self) -> str: ...

class Version:
    major: int
    minor: int
    patch: int
    res: int
    def __str__(self) -> str: ...

class VendorInfo:
    product_model: str
    product_seq_num: str
    hardware_version: Version
    software_version: Version
    voltage: int
    dof: int
    def __str__(self) -> str: ...

class DeviceInfo:
    hand_device_id: int
    commu_params: CommuParams
    def __str__(self) -> str: ...

class JointMotorErrorReport:
    stalled: bool
    overheat: bool
    over_current: bool
    motor_except: bool
    commu_except: bool

class MixCtrl:
    joint_index: int
    ctrl_mode: int
    tgt_posi: int
    tgt_velo: int
    tgt_torque: int

class Int16Bound:
    min_value: int
    max_value: int

class Int16Range:
    min_value: int
    max_value: int
    default_value: int

class FloatBound:
    min_value: float
    max_value: float

class TactileSensorData:
    """OmniHand 2025 (O10) 1D tactile sensor data"""
    sensor_id: int  # Finger enum value
    data: List[int]  # Raw sensor data (unit: 1g, max: 255g)

class TactileSensor3DData:
    """OmniHand Pro 2025 (O12) 3D tactile sensor data"""
    online_state: int
    channel_values: List[int]  # 9 channels
    normal_force: int
    tangent_force: int
    tangent_force_angle: int
    capacitive_approach: List[int]  # 4 channels

class OmniHand:
    """Unified OmniHand class supporting both O10 and O12"""
    
    @staticmethod
    def create_hand_by_zlgcan(
        product_type: int,
        hand_type: int = 0,
        hand_device_id: int = 1,
        canfd_device_id: int = 0,
        canfd_channel_id: int = 0
    ) -> "OmniHand":
        """Create OmniHand instance over ZLG CAN."""
        ...
    
    @staticmethod
    def create_hand_by_zlgcan(
        product_type: int,
        hand_type: int,
        hand_device_id: int,
        usbcanfd_serial_number: str,
        canfd_channel_id: int = 0
    ) -> "OmniHand":
        """Create OmniHand instance over ZLG CAN (by serial number)."""
        ...
    
    @staticmethod
    def create_hand_by_rs485(
        product_type: int,
        hand_type: int = 0,
        hand_device_id: int = 1,
        uart_port: str = "/dev/ttyUSB0",
        baudrate: int = 460800
    ) -> "OmniHand":
        """Create OmniHand instance over RS485 (OmniHand 2025 only)."""
        ...
    
    @staticmethod
    def create_hand_by_hcan(
        product_type: int,
        hand_type: int = 0,
        hand_device_id: int = 1,
        canfd_device_id: int = 0,
        canfd_channel_id: int = 0
    ) -> "OmniHand":
        """Create OmniHand instance over HCAN USB CANFD (by device ID)."""
        ...
    
    @staticmethod
    def create_hand_by_hcan(
        product_type: int,
        hand_type: int,
        hand_device_id: int,
        hcan_serial_number: str,
        canfd_channel_id: int = 0
    ) -> "OmniHand":
        """Create OmniHand instance over HCAN USB CANFD (by serial number)."""
        ...
    
    @staticmethod
    def create_hand_socketcan(
        product_type: int,
        hand_type: int = 0,
        hand_device_id: int = 1,
        can_interface: str = "can0"
    ) -> "OmniHand":
        """Create OmniHand instance over SocketCAN (Linux only)."""
        ...
    
    def init(self) -> bool:
        """Check initialization status."""
        ...
    
    def get_product_type(self) -> int:
        """Get product type."""
        ...
    
    def set_device_id(self, device_id: int) -> None: ...
    def get_vendor_info(self) -> VendorInfo: ...
    def get_device_info(self) -> DeviceInfo: ...
    
    def set_joint_position(self, joint_motor_index: int, posi: int) -> None:
        """
        Set single joint motor position
        
        Args:
            joint_motor_index: Joint motor index
            posi: Motor position value
                - OmniHand 2025 (O10): range 0-4096
                - OmniHand Pro 2025 (O12): range 0-2000
        """
        ...
    
    def get_joint_position(self, joint_motor_index: int) -> int:
        """
        Get single joint motor position
        
        Args:
            joint_motor_index: Joint motor index
            
        Returns:
            Motor position value
                - OmniHand 2025 (O10): range 0-4096
                - OmniHand Pro 2025 (O12): range 0-2000
        """
        ...
    
    def set_all_joint_positions(self, vec_posi: List[int]) -> List[int]:
        """
        Set all joint motor positions and return actual positions
        
        Args:
            vec_posi: List of motor position values
                - OmniHand 2025 (O10): 10 values, each in range 0-4096
                - OmniHand Pro 2025 (O12): 12 values, each in range 0-2000
        
        Returns:
            List of actual positions from device response. Empty list on failure.
        """
        ...
    
    def get_all_joint_positions(self) -> List[int]:
        """
        Get all joint motor positions
        
        Returns:
            List of motor position values
                - OmniHand 2025 (O10): 10 values, each in range 0-4096
                - OmniHand Pro 2025 (O12): 12 values, each in range 0-2000
        """
        ...
    
    def set_all_active_joint_angles(self, angles: List[float]) -> None: ...
    def set_hand_gesture(self, gesture_num: int = 1) -> None: ...  # default is product-specific (O10: 1=FIST1)
    def get_all_active_joint_angles(self) -> List[float]: ...
    def get_all_joint_angles(self, active_joint_angles: Optional[List[float]] = None) -> List[float]: ...
    
    def set_joint_velocity(self, joint_motor_index: int, velo: int) -> None: ...
    def get_joint_velocity(self, joint_motor_index: int) -> int: ...
    def set_all_joint_velocities(self, vec_velo: List[int]) -> None: ...
    def get_all_joint_velocities(self) -> List[int]: ...
    
    def get_tactile_sensor_data(self, finger_index: int) -> List[int]:
        """Get tactile sensor data (OmniHand 2025 O10 only, returns vector<uint8_t>)."""
        ...
    
    def get_tactile_sensor_3d_data(self, finger_index: int) -> TactileSensor3DData:
        """Get 3D tactile sensor data (OmniHand Pro 2025 O12 only, returns TactileSensor3DData)."""
        ...
    
    def get_all_tactile_sensor_data_raw(self) -> List[TactileSensorData]:
        """Get all 1D tactile sensor raw data (OmniHand 2025 O10 only, returns vector<TactileSensorData>, full resolution)."""
        ...
    
    def get_tactile_sensor_data_raw(self, finger_index: int) -> TactileSensorData:
        """Get single 1D tactile sensor raw data (OmniHand 2025 O10 only, returns TactileSensorData, full resolution)."""
        ...
    
    def set_current_threshold(self, joint_motor_index: int, current_threshold: int) -> None: ...
    def get_current_threshold(self, joint_motor_index: int) -> int: ...
    def set_all_current_thresholds(self, current_thresholds: List[int]) -> None: ...
    def get_all_current_thresholds(self) -> List[int]: ...
    
    def mix_control_by_pt(self, positions: List[int], torques: List[int]) -> List[MixCtrl]: ...
    def mix_control_by_pvt(self, positions: List[int], velocities: List[int], torques: List[int]) -> List[MixCtrl]: ...
    
    def get_error_report(self, joint_motor_index: int) -> JointMotorErrorReport: ...
    def get_all_error_reports(self) -> List[JointMotorErrorReport]: ...
    def set_error_report_period(self, joint_motor_index: int, period: int) -> None: ...
    def set_all_error_report_periods(self, vec_period: List[int]) -> None: ...
    
    def get_temperature_report(self, joint_motor_index: int) -> int: ...
    def get_all_temperature_reports(self) -> List[int]: ...
    def set_temperature_report_period(self, joint_motor_index: int, period: int) -> None: ...
    def set_all_temperature_report_periods(self, vec_period: List[int]) -> None: ...
    
    def get_current_report(self, joint_motor_index: int) -> int: ...
    def get_all_current_reports(self) -> List[int]: ...
    def set_current_report_period(self, joint_motor_index: int, period: int) -> None: ...
    def set_all_current_report_periods(self, vec_period: List[int]) -> None: ...
    
    # Position calibration (UMI specific)
    def set_min_position_calibration(self) -> None:
        """Set minimum position calibration (UMI Protocol Pn7, sub-register 0x00). Only available for OmniHand Dex UMI."""
        ...
    
    def set_max_position_calibration(self) -> None:
        """Set maximum position calibration (UMI Protocol Pn8, sub-register 0x00). Only available for OmniHand Dex UMI."""
        ...
    
    # Note: UMI does not support periodic reports. Use get_joint_position() or get_all_joint_positions() for active position query.
    
    def set_tactile_sensor_report_callback(
        self, 
        callback: "Callable[[TactileSensorData, int], None] | None", 
        frequency: int | None = None
    ) -> None:
        """
        Register callback function for tactile sensor periodic report (UMI Protocol Pn6, Pn2.04 sets frequency).
        
        Args:
            callback: Callback function that receives TactileSensorData and sensor_id (int).
                     Set to None to unregister.
            frequency: Optional frequency in Hz. If provided, sets Pn2.04 before registering callback.
        
        Note:
            Only available for OmniHand Dex UMI.
            The callback will be called in a background thread, so it should be thread-safe.
        """
        ...
    
    def show_data_details(self, show: bool) -> None: ...
    
    def set_request_interval(self, milliseconds: int) -> None:
        """
        Set request interval to control CAN bus communication rate
        
        Args:
            milliseconds: Minimum interval between requests in milliseconds (0-100ms, 0 = no limit, default: 30ms)
        """
        ...
    def get_request_interval(self) -> int:
        """
        Get current request interval setting
        
        Returns:
            Request interval in milliseconds (0 = no limit, 0 for RS485 = not applicable)
        """
        ...
    def set_frame_recv_timeout(self, milliseconds: int) -> None:
        """
        Set frame reception timeout
        
        Args:
            milliseconds: Timeout for receiving a single frame (10-1000ms, default: 50ms)
        
        Note:
            - This timeout applies to both single-frame and multi-frame reception
            - For multi-frame reception, this timeout applies to each frame individually
            - Only applies to CAN communication. RS485 communication is not affected.
            - Serial port communication (RS485) does not support this interface.
        """
        ...
    def get_frame_recv_timeout(self) -> int:
        """
        Get current frame reception timeout setting
        
        Returns:
            Frame reception timeout in milliseconds (0 for RS485 = not applicable)
        
        Note:
            Serial port communication (RS485) always returns 0 (not applicable).
        """
        ...

# --- Product-line classes (omnihand_core) ---

class OmniHand2025(OmniHand):
    kDegreesOfActiveFreedom: int
    kDefaultHandDeviceId: int
    def set_hand_gesture(
        self,
        gesture: OmniHand2025Gesture = OmniHand2025Gesture.OMNIHAND_2025_GESTURE_FIST1,
    ) -> None: ...
class OmniHandPro2025(OmniHand):
    kDegreesOfActiveFreedom: int
    kDefaultHandDeviceId: int
    def set_control_mode(self, joint_motor_index: int, mode: int) -> None: ...
    def get_control_mode(self, joint_motor_index: int) -> int: ...
    def set_all_control_modes(self, ctrl_modes: List[int]) -> None: ...
    def get_all_control_modes(self) -> List[int]: ...
    def set_joint_torque(self, joint_motor_index: int, torque: int) -> None: ...
    def get_joint_torque(self, joint_motor_index: int) -> int: ...
    def set_all_joint_torques(self, vec_torque: List[int]) -> None: ...
    def get_all_joint_torques(self) -> List[int]: ...
    def set_joint_voltage(self, joint_motor_index: int, voltage: int) -> None: ...
    # O12 firmware versions up to and including 1.2.15 do not support voltage readback.
    def get_joint_voltage(self, joint_motor_index: int) -> int: ...
    def set_all_joint_voltages(self, vec_voltage: List[int]) -> None: ...
    # O12 firmware versions up to and including 1.2.15 do not support voltage readback.
    def get_all_joint_voltages(self) -> List[int]: ...

class OmniHand3Lite(OmniHand):
    kDegreesOfActiveFreedom: int
    kDefaultHandDeviceId: int
    def get_joint_names(self) -> List[str]: ...
    @staticmethod
    def get_num_of_joint_motors() -> int: ...
    @staticmethod
    def get_doa() -> int: ...
    @staticmethod
    def get_dop() -> int: ...
    @staticmethod
    def get_min_max_motor_position(joint_motor_index: int) -> Int16Bound: ...
    @staticmethod
    def get_min_max_actual_motor_position(joint_motor_index: int) -> Int16Bound: ...
    @staticmethod
    def get_min_max_default_mix_ctrl_velocity(joint_motor_index: int) -> Int16Range: ...
    @staticmethod
    def get_min_max_default_mix_ctrl_torque(joint_motor_index: int) -> Int16Range: ...
    @staticmethod
    def get_min_max_activate_joint_angle(joint_motor_index: int, hand_type: int) -> FloatBound: ...

class OmniHand3UltraM(OmniHand):
    kDegreesOfActiveFreedom: int
    kDefaultHandDeviceId: int
    def set_control_mode(self, joint_motor_index: int, mode: int) -> None: ...
    def get_control_mode(self, joint_motor_index: int) -> int: ...
    def set_all_control_modes(self, ctrl_modes: List[int]) -> None: ...
    def get_all_control_modes(self) -> List[int]: ...

class OmniHandDexUMI(OmniHand):
    """Dex UMI supports direct CAN transports."""
    kDegreesOfActiveFreedom: int
    kDefaultHandDeviceId: int
