# Copyright (c) 2025, Agibot Co., Ltd.
# OmniHand 2025 SDK is licensed under Mulan PSL v2

"""
OmniHand Pro 2025 (O12) Solver Module Type Stubs
提供12自由度灵巧手的运动学求解器接口
"""

from typing import List

class OmniHandPro2025Solver:
    """OmniHand Pro 2025 (O12) kinematics solver - 12自由度灵巧手运动学求解器"""
    
    def __init__(self, hand_type: bool) -> None:
        """
        构造函数
        
        Args:
            hand_type: True=左手, False=右手
        """
        ...
    
    def check_joint_pos(self, active_joint_pos: List[float]) -> bool:
        """
        检查关节位置是否在限制范围内
        
        Args:
            active_joint_pos: 主动关节位置向量（会被修改）
            
        Returns:
            是否在限制范围内
        """
        ...
    
    def check_actuator_input(self, actuator_input: List[int]) -> bool:
        """
        检查执行器输入
        
        Args:
            actuator_input: 执行器输入向量
            
        Returns:
            是否有效
        """
        ...
    
    def set_hand_gesture(self, gesture_num: int) -> List[int]:
        """
        设置预定义手势
        
        Args:
            gesture_num: 手势索引
            
        Returns:
            执行器命令向量
        """
        ...
    
    def convert_joint_to_actuator(self, active_joint_pos: List[float]) -> List[int]:
        """
        Convert active joint position to actuator input
        
        Args:
            active_joint_pos: Active joint position vector
            
        Returns:
            Actuator command vector (range: 0-2000)
            
        Note:
            O12 motor input range is 0-2000, different from O10 which is 0-4096
        """
        ...
    
    def convert_actuator_to_joint(self, actuator_input: List[int]) -> List[float]:
        """
        Convert actuator input to active joint position
        
        Args:
            actuator_input: Actuator command vector (range: 0-2000)
            
        Returns:
            Active joint position vector
            
        Note:
            O12 motor input range is 0-2000, different from O10 which is 0-4096
        """
        ...
    
    def active_joint_to_motor_length(self, active_joint_pos: List[float]) -> List[float]:
        """
        主动关节位置转电机长度
        
        Args:
            active_joint_pos: 主动关节位置向量
            
        Returns:
            电机长度向量
        """
        ...
    
    def motor_length_to_active_joint(self, motor_length: List[float]) -> List[float]:
        """
        电机长度转主动关节位置
        
        Args:
            motor_length: 电机长度向量
            
        Returns:
            主动关节位置向量
        """
        ...
    
    def motor_length_to_motor_input(self, motor_length: List[float]) -> List[int]:
        """
        电机长度转电机输入值
        
        Args:
            motor_length: 电机长度向量
            
        Returns:
            电机输入值向量
        """
        ...
    
    def motor_input_to_motor_length(self, motor_input: List[int]) -> List[float]:
        """
        电机输入值转电机长度
        
        Args:
            motor_input: 电机输入值向量
            
        Returns:
            电机长度向量
        """
        ...
    
    def get_all_joint_pos(self, active_joint_pos: List[float]) -> List[float]:
        """
        获取所有关节位置 (主动+被动)
        
        Args:
            active_joint_pos: 当前主动关节位置
            
        Returns:
            所有关节位置向量
        """
        ...
