# Copyright (c) 2025, Agibot Co., Ltd.
# AGILINK OmniHand SDK is licensed under Mulan PSL v2

"""WebSocket namespace — retained as an empty package for import compatibility."""

__all__ = []
