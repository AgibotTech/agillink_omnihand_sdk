"""OmniHand 3 Ultra M (H3U-M, O20) solver module."""

from ..omnihand_core import OmniHand3UltraMSolver

__all__ = ["OmniHand3UltraMSolver"]
