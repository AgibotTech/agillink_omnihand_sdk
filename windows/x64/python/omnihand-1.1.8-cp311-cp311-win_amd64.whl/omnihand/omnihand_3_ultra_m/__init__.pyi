# Copyright (c) 2025, Agibot Co., Ltd.
# AGILINK OmniHand SDK is licensed under Mulan PSL v2

"""OmniHand 3 Ultra M (H3U-M, O20) kinematics solver type stubs."""

from typing import List

ACTIVE_JOINT_COUNT: int
ACTUATOR_INPUT_MIN: int
ACTUATOR_INPUT_MAX: int

class OmniHand3UltraMSolver:
    """Per-joint linear rad <-> actuator-input solver for H3U-M (O20, 20 DOF)."""

    def __init__(self, is_left_hand: bool) -> None:
        """is_left_hand: True = left hand, False = right hand."""
        ...

    def active_joint_pos_to_actuator_input(
        self, active_joint_pos: List[float]
    ) -> List[int]:
        """Convert 20 joint angles (rad) to 20 actuator inputs in [0, 4096]."""
        ...

    def actuator_input_to_active_joint_pos(
        self, actuator_input: List[int]
    ) -> List[float]:
        """Convert 20 actuator inputs to 20 joint angles (rad)."""
        ...
