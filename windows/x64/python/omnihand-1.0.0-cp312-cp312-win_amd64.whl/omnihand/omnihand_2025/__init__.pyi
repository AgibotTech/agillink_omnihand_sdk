# Copyright (c) 2025, Agibot Co., Ltd.
# OmniHand 2025 SDK is licensed under Mulan PSL v2

"""
OmniHand 2025 (O10) Solver Module Type Stubs
"""

from typing import List

class OmniHand2025Solver:
    """OmniHand 2025 (O10) kinematics solver"""
    
    def __init__(self, hand_type: bool) -> None:
        """
        Constructor
        
        Args:
            hand_type: True=left hand, False=right hand
        """
        ...
    
    def set_hand_gesture(self, gesture_num: int) -> List[int]:
        """
        Set predefined hand gesture
        
        Args:
            gesture_num: Hand gesture index
            
        Returns:
            Actuator command vector
        """
        ...
    
    def active_joint_pos_to_actuator_input(self, active_joint_pos: List[float]) -> List[int]:
        """
        Convert active joint position to actuator input
        
        Args:
            active_joint_pos: Active joint position vector
            
        Returns:
            Actuator command vector (range: 0-4096)
            
        Note:
            O10 motor input range is 0-4096, different from O12 which is 0-2000
        """
        ...
    
    def actuator_input_to_active_joint_pos(self, actuator_input: List[int]) -> List[float]:
        """
        Convert actuator input to active joint position
        
        Args:
            actuator_input: Actuator command vector (range: 0-4096)
            
        Returns:
            Active joint position vector
            
        Note:
            O10 motor input range is 0-4096, different from O12 which is 0-2000
        """
        ...
    
    def get_all_joint_pos(self, active_joint_pos: List[float]) -> List[float]:
        """
        Get all joint positions (active + passive)
        
        Args:
            active_joint_pos: Current active joint position
            
        Returns:
            All joint position vector
        """
        ...
    
    def show_log(self, flag: bool) -> None:
        """
        Show log
        
        Args:
            flag: Whether to show log
        """
        ...
