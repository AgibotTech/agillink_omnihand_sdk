"""
OmniHand 2025 (O10) Solver Module
"""

from ..omnihand_core import OmniHand2025Solver

__all__ = ['OmniHand2025Solver']
